/*
 * Obstacal avoiding car.c
 *
 * Created: 5/15/2023 2:33:27 PM
 * Author : engma
 */ 

//#include <avr/io.h>

#include "APP/app.h"

int main(void)
{
    APP_vidInit();
    /* Replace with your application code */
    while (1) 
    {
        APP_vidStart();
    }
}

