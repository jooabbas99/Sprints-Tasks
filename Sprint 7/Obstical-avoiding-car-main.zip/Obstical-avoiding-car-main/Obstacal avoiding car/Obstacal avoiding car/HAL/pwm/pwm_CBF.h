/*
 * pwm_CBF.h
 *
 * Created: 5/20/2023 4:18:41 AM
 *  Author: Mahmoud Sarhan
 */ 


#ifndef PWM_CBF_H_
#define PWM_CBF_H_


void TIMER0_callBackFunc(void);


#endif /* PWM_CBF_H_ */