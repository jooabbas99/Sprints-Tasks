/*
 * hextInt_cfg.h
 *
 * Created: 5/19/2023 4:39:21 PM
 *  Author: hp
 */ 


#ifndef HEXTINT_CFG_H_
#define HEXTINT_CFG_H_

#define INT_0_PIN	portd,pin2
#define INT_1_PIN	portd,pin3

#define HEXTINT_TYPE		HEXTINT_INT0

#endif /* HEXTINT_CFG_H_ */