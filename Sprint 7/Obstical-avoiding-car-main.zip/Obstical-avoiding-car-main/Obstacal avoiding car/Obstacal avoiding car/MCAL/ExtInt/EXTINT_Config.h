/*
 * EXTINT_Config.h
 *
 *  Created on: Apr 3, 2023
 *      Author: hp
 */

#ifndef MCAL_EXTINT_EXTINT_CONFIG_H_
#define MCAL_EXTINT_EXTINT_CONFIG_H_



#endif /* 04_MCAL_EXTINT_EXTINT_CONFIG_H_ */
