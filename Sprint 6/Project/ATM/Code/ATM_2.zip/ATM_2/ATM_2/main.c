/*
 * ATM.c
 *
 * Created: 5/2/2023 6:46:35 PM
 * Author : Youssef Abbas
 */ 


#include "Application/application.h"

int main(void)
{
	appInit();
	while (1) 
    {
		appStart();
    }
}

