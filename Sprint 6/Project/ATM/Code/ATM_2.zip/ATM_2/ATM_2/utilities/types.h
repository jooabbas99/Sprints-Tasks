#ifndef TYPES_H
#define TYPES_H
typedef unsigned char uint8 ;
typedef unsigned int uint32;
typedef unsigned short uint16;
#define NULL_PTR    ((void*)0)

#endif //ATMEGA32A_TYPES_H
