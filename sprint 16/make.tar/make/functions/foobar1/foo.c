#include "foo.h"

void
foo()
{
    printf("Hello from foo!\n");
}