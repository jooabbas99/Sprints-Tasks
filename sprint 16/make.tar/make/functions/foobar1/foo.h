#ifndef _FOO_H
#define _FOO_H

#include <stdio.h>

void foo();

#endif