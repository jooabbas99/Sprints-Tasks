#ifndef _BAR_H
#define _BAR_H

#include <stdio.h>

void bar();

#endif
