#include "bar.h"

void
bar()
{
    printf("Hello form bar!\n");
}
