#ifndef _FOO_H
#define _FOO_H

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void foo();

#endif
