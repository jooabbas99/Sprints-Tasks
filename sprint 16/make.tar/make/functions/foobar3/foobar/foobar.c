#include "foobar.h"

int
main()
{
    foo();
    bar();
    return 0;
}

void
foobar()
{
    foo();
    bar();
}
