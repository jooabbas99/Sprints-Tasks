#ifndef _FOOBAR_H
#define _FOOBAR_H

#include "foo.h"
#include "bar.h"

void foobar();

#endif /* _FOOBAR_H */
