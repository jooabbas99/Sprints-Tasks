#include "foobar.h"

int
main()
{
    foobar();
    return 0;
}

void
foobar()
{
    foo();
    bar();
}
