/*
 * IncFile1.h
 *
 * Created: 4/25/2023 5:47:09 PM
 *  Author: youss
 */ 


#ifndef INCFILE1_H_
#define INCFILE1_H_



void AppInit(void);
void AppStart(void);




#endif /* INCFILE1_H_ */