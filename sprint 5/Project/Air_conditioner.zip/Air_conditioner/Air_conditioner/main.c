/*
 * Air_conditioner.c
 *
 * Created: 2023-04-22 8:22:20 AM
 * Author : HAZEM-PC
 */ 

#define F_CPU 16000000UL
/*============= FILE INCLUSION =============*/
#include "HAL/KEYPAD/keypad.h"
#include "HAL/LCD/lcd.h"
#include "HAL/Temp_sensor/LM35.h"
#include "HAL/LED/LED.h"
#include "MCAL/TIMER_0/TIMER_0.h"
#include "Application/Application.h"

/*============= TYPE DEFINITION =============*/
typedef enum{
	S_reset,S_adjust,S_set,S_max
}EN_state;
typedef enum{
	E_reset,E_adjust,E_set,E_readjust,E_max
}EN_event;

/*============= GLOBAL VARIABLES =============*/
uint8 currrent_state=S_reset;
uint8 buffer_temp=25;
uint8 default_temp=25;
uint8 set_temp=25;
uint8 Actual_temp=0;
uint8 label_size=8;

/*============= FUNCTION PROTOTYPE =============*/
uint8 ReadKeyinput(uint8* key);
void stateMachine(uint8 event,uint8 key);
void Reset_Mode(void);
void set_mode(void);
void adjust_mode(uint8 key);
void warning_message(void);
void pre_set(void);

/*============= MAIN CODE =============*/
int main()
{
	AppInit();
	
	while (1)
	{
	AppStart();
	
	}
	//uint8 button,event;
	//LCD_init();
	//ADC_init(AVCC,F_8);
	//LED_init(PORTD_ID,PIN0);
	//Reset_Mode();
    //while(1)
    //{
		//event=ReadKeyinput(&button);
		//stateMachine(event,button);
    //}
}


void Reset_Mode(void)
{
	buffer_temp=25;
	label_size=8;
	set_temp=25;
	Actual_temp=LM35_getTemperature(ADC0);
	if(Actual_temp > set_temp)
	{
		LED_digitalwrite(PORTD_ID,PIN0,High);
	}
	else
	{
		LED_digitalwrite(PORTD_ID,PIN0,Low);
	}
	LCD_clearScreen();
	LCD_displayStringRowColumn(0,4,"welcome");
	Timer0_Delay(1000);
	LCD_displayStringRowColumn(1,0,"default temp=");
	LCD_moveCursor(1,14);
	LCD_intgerToString(default_temp);
	Timer0_Delay(1000);
	LCD_clearScreen();
	LCD_displayString("set Temperature");
	Timer0_Delay(1000);
	LCD_clearScreen();
	LCD_displayString("min=18    max=35");
	LCD_moveCursor(0,7);
	LCD_intgerToString(buffer_temp);
}

void pre_set(void)
{
	LCD_clearScreen();
	LCD_displayString("min=18    max=35");
	LCD_moveCursor(0,7);
	LCD_intgerToString(buffer_temp);
}
	

void set_mode(void)
{
	Actual_temp=LM35_getTemperature(ADC0);
	if(Actual_temp > set_temp)
	{
		LED_digitalwrite(PORTD_ID,PIN0,High);
	}
	else
	{
		LED_digitalwrite(PORTD_ID,PIN0,Low);
	}
	LCD_clearScreen();
	LCD_displayStringRowColumn(0,0,"set temp=");
	LCD_moveCursor(0,9);
	LCD_intgerToString(set_temp);
	LCD_displayStringRowColumn(1,0,"Actual temp=");
	LCD_moveCursor(1,12);
	LCD_intgerToString(Actual_temp);	
}

void adjust_mode(uint8 key)
{
	uint8 label[16]=">>>>>>>>>>>>>>>>";
	if(key==1)
	{
		buffer_temp++;
		label_size++;
		if(label_size>=16)
		label_size=16;
		if(buffer_temp>=35)
		{
			LCD_clearScreen();
			LCD_displayString("out of range");
			Timer0_Delay(1000);
			buffer_temp=35;
		}

	}
	else if(key==2)
	{
		buffer_temp--;
		label_size--;
		if(label_size<=3)
		label_size=3;
		if(buffer_temp<=18)
		{
			LCD_clearScreen();
			LCD_displayString("out of range");
			Timer0_Delay(1000);
			buffer_temp=18;
		}
	}
	else
	{	
	}
	set_temp=buffer_temp;
	LCD_clearScreen();
	LCD_displayString("min=18    max=35");
	LCD_moveCursor(0,7);
	LCD_intgerToString(buffer_temp);
	LCD_moveCursor(1,0);
	for(int i=0;i<label_size;i++)
	LCD_displayCharacter(label[i]);
}

uint8 ReadKeyinput(uint8* key)
{
	*key=KEYPAD_getPressedKey();
	Timer0_Delay(250);
	switch(*key)
	{
		case 1:
			return E_adjust;
			break;
		case 2:
			return E_adjust;
			break;
		case 3:
			return E_set;
			break;
		case 4:
			return E_readjust;
			break;
		case 5:
			return E_reset;
			break;
		default:
			return E_max;
			break;
	}	
}

void warning_message(void)
{
	LCD_clearScreen();
	LCD_displayString("  operation not");
	LCD_displayStringRowColumn(1,5,"allowed");
	Timer0_Delay(1500);
}

void stateMachine(uint8 event,uint8 key)
{

	switch(currrent_state)
	{
		case S_reset:
		{
			switch (event)
			{
				case E_adjust:
					adjust_mode(key);
					currrent_state=S_adjust;
					break;
				case E_set:
					set_mode();
					currrent_state=S_set;				
					break;
				default:
					warning_message();
					pre_set();
					currrent_state=S_reset;
					break;
			}
		}
		break;
		case S_adjust:
		{
			switch (event)
			{
				case E_adjust:
					adjust_mode(key);
					currrent_state=S_adjust;
					break;
				case E_set:
					set_mode();
					currrent_state=S_set;
					break;
				case E_reset:
					Reset_Mode();
					currrent_state=S_reset;				
					break;
				default:
					warning_message();
					adjust_mode(key);
					currrent_state=S_adjust;
					break;
			}
		break;
		}
		case S_set:
		{
			switch (event)
			{
				case E_readjust:
					adjust_mode(key);
					currrent_state=S_adjust;
					break;
				case E_reset:
					Reset_Mode();
					currrent_state=S_reset;
					break;
				default:
					warning_message();
					set_mode();
					currrent_state=S_set;
					break;
			}
		}
		break;
	}
}